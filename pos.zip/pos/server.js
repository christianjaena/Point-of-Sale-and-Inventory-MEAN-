var express = require('express');
var app = express();
var mongojs = require('mongojs');
var db = mongojs('productlist', ['productlist']);
var db2 = mongojs('sales', ['sales']);
var bodyParser = require('body-parser');
var morgan = require('morgan');
var port = process.env.port || 3000;

app.use(express.static(__dirname + '/public'));
app.use(morgan('dev'));
app.use(bodyParser.json());

app.get('/productlist', function (req, res) {
  console.log('SERVER RECEIVED A GET REQUEST');

  db.productlist.find(function (err, docs) {
    console.log(docs);
    res.json(docs);
  });
});

app.post('/productlist', function (req, res) {
  console.log('SERVER RECEIVED A POST REQUEST');
  console.log(req.body);
  db.productlist.insert(req.body, function(err, doc) {
    res.json(doc);
  });
});


app.post('/sales', function (req, res) {
  console.log('SERVER RECEIVED A POST REQUEST');
  console.log(req.body);
  db2.sales.insert(req.body, function(err, doc) {
    res.json(doc);
  });
});

app.get('/sales', function (req, res) {
  console.log('SERVER RECEIVED A GET REQUEST');

  db2.sales.find(function (err, docs) {
    console.log(docs);
    res.json(docs);
  });
});

app.delete('/sales', function(req,res){
	console.log('CLEARED SALES')
	db2.sales.remove({}, function(err,doc){
		res.json(doc)
	});
})


app.delete('/productlist/:id', function (req, res) {
  console.log('SERVER RECEIVED A DELETE REQUEST');
  var id = req.params.id;
  console.log(id);
  db.productlist.remove({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.get('/productlist/:id', function (req, res) {
  console.log('SERVER RECEIVED A GET REQUEST');
  var id = req.params.id;
  console.log(id);
  db.productlist.findOne({_id: mongojs.ObjectId(id)}, function (err, doc) {
    res.json(doc);
  });
});

app.put('/productlist/:id', function (req, res) {
  console.log('SERVER RECEIVED AN UPDATE REQUEST');
  var id = req.params.id;
  console.log(req.body.name);
  db.productlist.findAndModify({
    query: {_id: mongojs.ObjectId(id)},
    update: {$set: {name: req.body.name, price: req.body.price, stock: req.body.stock}},
    new: true}, function (err, doc) {
      res.json(doc);
    }
  );
});

app.listen(port);
console.log("SERVER RUNNING ON PORT " + port);