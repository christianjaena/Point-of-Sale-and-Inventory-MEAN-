var myApp = angular.module('myApp', []);


myApp.controller('AppCtrl', ['$scope', '$http', function($scope, $http) {
    

var refresh = function() {
  $http.get('/productlist').success(function(response) {

    $scope.productlist = response;
    $scope.product = "";
    $http.get('/sales').success(function(response2) {
    $scope.sales = response2;
    
    for (var i = 0; i <= response2.length; i++) {
      var or = response2[i].or + 1
      $scope.orderNumber = or
    }
    
    });
    
  });

};

orderNumber +=1
refresh();



$scope.addProduct = function() {
  console.log($scope.product);
  $http.post('/productlist', $scope.product).success(function(response) {
    console.log(response);
    refresh();
  });
};

$scope.remove = function(id) {
  console.log(id);
  $http.delete('/productlist/' + id).success(function(response) {
    refresh();
  });
};

$scope.edit = function(id) {
  
  $http.get('/productlist/' + id).success(function(response) {
    $scope.product = response;
  });
};  

$scope.update = function() {
  console.log("PRODUCT WITH ID: "+$scope.product._id +" UPDATED");
  $http.put('/productlist/' + $scope.product._id, $scope.product).success(function(response) {
  refresh();
  })
};

$scope.deselect = function() {
  $scope.product = "";
}


var orders = []
var qty = []
var itemPrice = []
var sales = []
var numberOfOrders = 0
var totalPrice = 0
var orderNumber = 1000001
$scope.orderNumber = orderNumber

$scope.Date = Date.now()
$scope.show = false


$scope.toggle = function(){
  $scope.show = true

}
$scope.close = function(){
  $scope.show = false
}

$scope.addToCart = function(id, orderQuantity){
    
    
   
    $http.get('/productlist/' + id).success(function(response){
     if(response.stock == 0){
      alert("This item is out of stock!")
     } 
    else if(response.stock >= orderQuantity){
    orders.push({
      id: response._id,
      or: $scope.orderNumber,
      name: response.name,
      price: parseFloat(response.price),
      qty: parseInt(orderQuantity),
      stock: parseInt(response.stock),
      subtotal: parseInt(response.price*orderQuantity),
      date: Date.now()
    });

    sales.push({
      id: response.id,
      or: orderNumber,
      name: response.name,
      price: parseFloat(response.price),
      qty: parseInt(orderQuantity),
      subtotal: parseInt(response.price*orderQuantity),
      date: Date.now()
    });
  
    $scope.orderlist = orders
    $scope.sales = sales
    
    totalPrice += parseFloat(response.price*orderQuantity)
    $scope.totalPrice = totalPrice
    itemPrice.push(parseFloat(response.price*orderQuantity))
    console.log("PRODUCT WITH PRODUCT ID: " + id + " WAS ADDED TO CART");
    numberOfOrders += 1;
    $scope.ordersLength = numberOfOrders
    
  $http.get('/productlist/' + id).success(function(response) {
    $scope.product = response;
    response.stock-= orderQuantity
    if(response.stock <= 0){
      alert(response.name +' will be out of stock after this purchase.')
    }
   
    $http.put('/productlist/' + $scope.product._id, $scope.product).success(function(response) {
      refresh();
    })
  });
  }else{
      alert("Ordered Quantity is beyond maximum!")
    }
});

}

$scope.removeFromCart = function(order){


  var removeFromCart = $scope.orderlist.indexOf(order)
  var removed = orders.splice(removeFromCart,1)
$http.get('/productlist/' + removed[0].id).success(function(response){
  $scope.product = response
  response.stock += removed[0].qty
  $http.put('/productlist/' + $scope.product._id, $scope.product).success(function(response){
    refresh();
    removed.pop()
    
  })
})

  totalPrice -= itemPrice.splice(removeFromCart,1)
  $scope.totalPrice = totalPrice
  numberOfOrders -= 1;
  $scope.ordersLength = numberOfOrders
  
}

$scope.printContent = function (el){
  if($scope.cash<totalPrice){
    alert('Insufficient cash!')
  } 
  else {
  purchase();
  var restorePage =  document.body.innerHTML;
  var printcontent = document.getElementById(el).innerHTML;
  document.body.innerHTML = printcontent;
  window.print();
  document.body.innerHTML = restorePage;
} 
}

var purchase = function (){
  if(numberOfOrders >= 1){

    alert('Purchased Successfully. Thank you for shopping!')
  $http.post('/sales', $scope.orderlist).success(function(response2) {
    console.log(response2);
    refresh();
  });
   
  }else{

   alert("Nothing was ordered.")
  }
}

$scope.clearSales = function(){
  $http.delete('/sales').success(function(response){
    console.log(response)
    refresh();
  })
}

}]);﻿
 